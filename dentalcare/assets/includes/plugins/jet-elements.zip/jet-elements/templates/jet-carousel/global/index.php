<?php
/**
 * Advanced carousel template
 */
$layout = $this->get_settings( 'item_layout' );
?>
<div class="jet-carousel-wrap">
	<?php $this->__get_global_looped_template( esc_attr( $layout ) . '/items', 'items_list' ); ?>
</div>